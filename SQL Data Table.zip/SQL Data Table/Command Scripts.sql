
SELECT *
FROM milk_production
WHERE Year IS NULL;
ALTER TABLE milk_production 
DROP COLUMN Year;

SELECT SUM(Value) AS TotalCoffeeProductionValue
FROM coffee_production
WHERE Year = 2015;

SELECT AVG(Value) AS AverageHoneyProduction
FROM honey_production
WHERE Year = 2022;

SELECT State , State_ANSI 
FROM state_lookup where State='IOWA';

SELECT MAX(Value) AS HighestYogurtProductionValue
FROM yogurt_production
WHERE Year = 2022;

SELECT DISTINCT h.State_ANSI 
FROM honey_production h
JOIN milk_production m ON h.State_ANSI = m.State_ANSI AND h.Year = m.Year
WHERE h.Year = 2022;

SELECT SUM(y.Value)
FROM yogurt_production y
WHERE y.Year = 2022 AND y.State_ANSI IN (
    SELECT DISTINCT c.State_ANSI FROM cheese_production c WHERE c.Year = 2022
);

SELECT SUM(Value) AS TotalMilkProduction
FROM milk_production
WHERE Year = 2023;

SELECT DISTINCT State_ANSI 
FROM cheese_production
WHERE Year = 2023 AND Period = 'APR' AND Value > 100000000;

SELECT SUM(Value) AS TotalCoffeeProduction
FROM coffee_production
WHERE Year = 2011;

SELECT AVG(Value) AS AverageHoneyProduction
FROM honey_production
WHERE Year = 2022;

SELECT State, State_ANSI 
FROM state_lookup
WHERE State='FLORIDA';

SELECT sl.State , COALESCE(cp.Value, 0) AS CheeseProductionValue
FROM state_lookup sl
LEFT JOIN cheese_production cp ON sl.State_ANSI = cp.State_ANSI AND cp.Year = 2023 AND cp.Period = 'APR'
where sl.State='NEW JERSEY' ;


SELECT SUM(yp.Value) AS TotalYogurtProduction
FROM yogurt_production yp
INNER JOIN cheese_production cp ON yp.State_ANSI = cp.State_ANSI
WHERE yp.Year = 2022 AND cp.Year = 2023;

SELECT sl.State 
FROM state_lookup sl
LEFT JOIN milk_production mp ON sl.State_ANSI = mp.State_ANSI AND mp.Year = 2023
WHERE mp.State_ANSI IS NULL;

SELECT sl.State , COALESCE(cp.Value, 0) AS CheeseProductionValue
FROM state_lookup sl
LEFT JOIN cheese_production cp ON sl.State_ANSI = cp.State_ANSI AND cp.Year = 2023 AND cp.Period = 'APR' ;

SELECT AVG(Value) AS AverageCoffeeProduction
FROM coffee_production
WHERE Year IN (
    SELECT DISTINCT Year
    FROM honey_production
    WHERE Value > 1000000
);



\

